package model;

import java.util.ArrayList;

public class WorldCup {
	
	public final static String DATA_D = "";
	
	private ArrayList<Viewer> viewers;
	private Participant firstP;
	private Participant lastP;
	
	private String name;
	
	public WorldCup(String name) {
		this.name = name;
	}
	
	public WorldCup(String name, Viewer firstV, Participant firstP) {
		this.name = name;
		viewers = new ArrayList<Viewer>();
		this.firstP = firstP;
	}
	
	public void chargeData(String direction) {
		
	}
	
}
